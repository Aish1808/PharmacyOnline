import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';

import { get_all_medicine } from './../Redux/Actions/medicine';

import ProductCard from '../Components/ProductCard';
import Base from './../Components/Base';
const Home = () => {
  const dispatch = useDispatch();
  const { medicineList } = useSelector((state) => state.medicine);

  useEffect(() => {
    dispatch(get_all_medicine());
  }, [dispatch]);

  return (
    <Base >
    <a className='text-base block mt-3xl:inline-block lg:mt-0 text-white mr-9 font-bold text-center text-5xl'>
            Welcome to the online pharmacy
            </a>
    
      <marquee direction="right" size="+2" className="bg-blue-400 py-2 px-2 font-bold">Hello User Welcome to Online Pharmacy Store🏥 
      Application  Hello User Welcome to Online Pharmacy Store🏥 
      Application  Hello User Welcome to Online Pharmacy Store🏥 
      Application   Hello User Welcome to Online Pharmacy Store🏥 Application </marquee>
      <div className='flex flex-wrap gap-2 p-3'>
        {medicineList ? (
          medicineList.map((medicine) => (
            <div key={medicine._id}>
              <ProductCard key={medicine.id} data={medicine} />
            </div>
          ))
        ) : (
          <h1>server not connected</h1>
        )}
        {}
      </div>
    </Base>
  );
};

export default Home;
//